<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculo de calorias diarias</title>
</head>

<body>
    <h1>CALCULO DE CALORIAS DIARIAS</h1>
    <p>Dietetica y nutricion</p>
    <?php
    $peso = $_POST["peso"];
    $actividadFD = $_POST["actividadFisicaDiaria"];
    $objetivo = $_POST["objetivo"];
    $biotipo = $_POST["biotipo"];


    /*Asignamos el objetivo min y max segun los valores elegidos*/
    $objetivo_min = 0;
    $objetivo_max = 0;
    switch ($biotipo) {
        case "sedentario":
            switch ($objetivo) {
                case "rebajar":
                    $objetivo_min = 10;
                    $objetivo_max = 12;
                    break;
                case "mantener":
                    $objetivo_min = 12;
                    $objetivo_max = 14;
                    break;
                default:
                    /* Si no encuentra un valor anterior se supondra que es aumentar */
                    $objetivo_min = 16;
                    $objetivo_max = 18;
                    break;
            }
            break;
        case "moderadoActivo":

            switch ($objetivo) {
                case "rebajar":
                    $objetivo_min = 12;
                    $objetivo_max = 14;
                    break;
                case "mantener":
                    $objetivo_min = 14;
                    $objetivo_max = 16;
                    break;
                default:
                    /* Si no encuentra un valor anterior se supondra que es aumentar */
                    $objetivo_min = 18;
                    $objetivo_max = 20;
                    break;
            }

        default:

            switch ($objetivo) {
                case "rebajar":
                    $objetivo_min = 14;
                    $objetivo_max = 16;
                    break;
                case "mantener":
                    $objetivo_min = 16;
                    $objetivo_max = 18;
                    break;
                default:
                    /* Si no encuentra un valor anterior se supondra que es aumentar */
                    $objetivo_min = 20;
                    $objetivo_max = 22;
                    break;
            }

            break;
    }

    $libras = round($peso * 2.2046);

    /*Calculamos las calorias minimas y maximas diarias*/
    $kcal_min = $libras * $objetivo_min;
    $kcal_max = $libras * $objetivo_max;

    //Calculamos las formulas de los macronutientes
    $cabohidratoMin = $kcal_min * 0.4 / 4;
    $proteinaMin = $kcal_min * 0.3 / 4;
    $grasasMin = $kcal_min * 0.3 / 9;

    $carbohidratoMax = $kcal_max * 0.4 / 4;
    $proteinaMax = $kcal_max * 0.3 / 4;
    $grasasMax = $kcal_max * 0.3 / 9;

    echo "<p><strong>Peso en KGs:</strong> $peso</p>";
    echo "<p><strong>Peso en Libras:</strong> $libras</p>";
    echo "<p><strong>Rango Kcal:</strong>$kcal_min (min) / $kcal_max (max)</p>";
    echo "<p>Distribucion de Macronutrientes</p>";
    echo "<ul>";
    echo "<li>Gramos de carbohidratos: $cabohidratoMin (min) $carbohidratoMax / (max)</li>";
    echo "<li>Gramos en proteinas: $proteinaMin (min) / $proteinaMax (max)</li>";
    echo "<li> Gramos en grasa: $grasasMin (min) / $grasasMax (max)</li>";
    echo "</ul>";
    ?>
</body>

</html>